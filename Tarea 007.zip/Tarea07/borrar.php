<?php include "Modelo/AlumnoModel.php"; ?>
<?php
$alumnos = new AlumnoModel();
$consulta = $alumnos -> delete($_GET['id']);
header('Location: index.php')
?>