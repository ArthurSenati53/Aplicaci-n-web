<?php include "Vista/templade/header.php"; ?>
<?php include "Modelo/AlumnoModel.php"; ?>
<?php 
if (isset($_POST['submit'])) {
    $alumno = [
        "nombre" => $_POST['nombre'],
        "genero" => $_POST['genero'],
        "edad" => $_POST['edad'],
        "carrera" => $_POST['carrera'],
    ];
    $alumnos = new AlumnoModel();

    if (isset($_GET['id'])) {
        $alumno['id'] = $_POST['id'];
        $consulta = $alumnos -> update($alumno);
    }else { $consulta = $alumnos->create($alumno); }
}
if (isset($_GET['id'])) {
    $id = $_GET['id'];
}
?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h2 class="et-4">Crea un alumno</h2>
            <hr>
            <form method="post">
                <input type="hidden" name="id" id="id" value="<?php echo $id ?>">
                <div class="form-group">
                    <label for="nombre">Nombre</label>
                    <input type="text" name="nombre" id="nombre" class="form-control">
                </div>
                <div class="form-group">
                    <label for="genero">Genero</label>
                    <input type="text" name="genero" id="genero" class="form-control">
                </div>
                <div class="form-group">
                    <label for="edad">Edad</label>
                    <input type="text" name="edad" id="edad" class="form-control">
                </div>
                <div class="form-group">
                    <label for="carrera">Carrera</label>
                    <input type="text" name="carrera" id="carrera" class="form-control">
                </div>
                <div class="form-group">
                    <input type="submit" name="submit" class="btn btn-primery" value="Enviar">
                    <a class="btn btn-primary" href="index.php">Regresar al inicio</a>
                </div>
            </form>
        </div>
    </div>
</div>
<?php include "Vista/templade/footer.php" ?>