<?php
    $alumnos = new AlumnoModel();
    $consulta = $alumnos->getAlumno();
?>
<div class='container'>
    <div class='row'>
        <div class='col-md-12'>
            <h2 class='mt-3'>Lista de alumnos</h2>
            <table class='table'>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nombre</th>
                        <th>Genero</th>
                        <th>Edad</th>
                        <th>Carrera</th>
                        <th>BORRAR</th>
                        <th>EDITAR</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($consulta as $fila){?>
                        <tr>
                            <td><?php echo $fila['id']; ?></td>
                            <td><?php echo $fila['nombre']; ?></td>
                            <td><?php echo $fila['genero']; ?></td>
                            <td><?php echo $fila['edad']; ?></td>
                            <td><?php echo $fila['carrera']; ?></td>
                            <td><a href="<?= 'borrar.php?id='.$fila["id"] ?>">Borrar</a></td>
                            <td><a href="<?= 'gestionar.php?id='.$fila["id"] ?>">Editar</a></td>
                        </tr>
                        <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>