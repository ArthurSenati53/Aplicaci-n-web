<?php
    $servidor = 'localhost';
    $usuario = 'root';
    $contrasena = '';
    $bd = 'colegio';

    $conexion = new mysqli($servidor, $usuario, $contrasena, $bd);
    if ($conexion -> connect_error) {
        die('Hubo un fallo en la conexion'. $conexion ->connect_error);
    }else { return $conexion; };
?>