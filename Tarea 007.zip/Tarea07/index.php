<?php include "Vista/templade/header.php"; ?>
<?php include "Modelo/AlumnoModel.php"; ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <a href="gestionar.php" class="btn btn-primary mt-4">Crear alumno</a>
            <hr>
        </div>
    </div>
</div>
<?php include "Vista/lista.php"; ?>
<?php include "Vista/templade/footer.php"; ?>