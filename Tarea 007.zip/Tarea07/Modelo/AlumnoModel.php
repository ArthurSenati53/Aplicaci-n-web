<?php
    class AlumnoModel{
        private $conexion;

        function __construct(){
            $this ->conexion = include 'Controlador/conexion.php';
        }
        function getAlumno(){

            $sql = 'SELECT * FROM alumno ORDER BY id DESC';
            $resultado = $this -> conexion -> query($sql);
            return $resultado;
        }
        function create($data){
            $sql = 'INSERT INTO Alumno (nombre, genero, edad, carrera) VALUES ("'.$data['nombre'].'","'.$data['genero'].'",'.$data['edad'].',"'.$data['carrera'].'")';
            if ($this -> conexion -> query($sql) == TRUE) {
                echo "Registrado correctamente";
            } else {
                echo $this -> conexion->error;
            }
            $this -> conexion -> close();
        }
        function update($data){
            $sql = 'UPDATE Alumno SET nombre = "'.$data['nombre'].'", genero = "'.$data['genero'].'", edad = '.$data['edad'].', carrera = "'.$data['carrera'].'" where id = '.$data['id'];
            if ($this -> conexion -> query($sql) == TRUE) {
                echo "Actualizacion correctamente";
            }else { echo $this -> conexion->error; }
            $this -> conexion -> close();
        }
        function delete($id){
            $sql = 'DELETE from Alumno where id = '.$id;
            if ($this -> conexion -> query($sql) == TRUE) {
                echo "Eliminado correctamente";
            }else { echo $this -> conexion->error; }
            $this->conexion->close();
        }
    }
?>